//const electron = require('electron');
const url = require('url');
const path = require('path');
const serialPort = require('serialport');
var nodeConsole = require('console');
var myConsole = new nodeConsole.Console(process.stdout, process.stderr);

const Readline = require('@serialport/parser-readline');
const parser = new Readline(); 

let premier =1;
let connexion1=1;
var ipc = require('electron').ipcMain;

//chargement d'élements directement d'electron
const {app, BrowserWindow, Menu} = require('electron');

let mainWindow;
//let portWindow;
//let parser;

//////////////////////////////////////////////////////////////////////////////////
var listePorts=[];
var port;

//////////////////////////////////////////////////////////////////////////////////



//Message from html to Main
ipc.on('receivePort', function(event, portOpen){
    port = portOpen;
});

// listen for the app to be ready
function createWindow () {
   mainWindow = new BrowserWindow({
    width: 1080,
    height: 750,
    webPreferences: {
      nodeIntegration: true,
      experimentalFeatures: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.loadFile('index.html');

  //Construction du menu
  const mainMenu = Menu.buildFromTemplate(mainMenuTemplate);
  Menu.setApplicationMenu(mainMenu);
    
};

//////////////////////////////////////////////////////////////////////////////////
//À partir d'ici!
//Il y a quelques catch et fonction erreurs qui manquent, mais ça fonctionne si on ne fait rien de
// trop bizarre
//On pourrait ajouter une vérification que c'est bien une carte arduino avec le nom des ports
//
//ouvrir la fenêtre de connexion
/*function createPortWindow(){
	portWindow = new BrowserWindow({
            width: 300,
            height: 300,
            alwaysOnTop: true,
            title:"Liste des ports",
            //frame: false,
        
            webPreferences: {
                    nodeIntegration: true,
                    experimentalFeatures: true,
            }
    });
    portWindow.loadFile('portW.html');
};*/

//quand on appuie sur le bourot "Afficher les ports"
ipc.on("btnDrop", function(event, arg){

    listePorts=[];
    serialPort.list().then(function(ports){
                ports.forEach(function(port){
                myConsole.log("Port info1: " + port.path );
                listePorts.push(port.path);
        });
         myConsole.log(listePorts);
         event.sender.send("list-finished", listePorts); 
    }).catch(function(e) {
        console.error(e.message);
    
    });
    
           
});       

//quand on appuie sur le bouton de connexion
ipc.on("connexion", function(event, path){
    var oui =0;
        myConsole.log(path);
        myConsole.log("12");
        port = new serialPort(String(path),{baudRate:9600, autoOpen:false},/*function(err) { 
                myConsole.log("6f8utf");
				/*if (err){
                        event.sender.send("connexion-finished", err); 
			  			return myConsole.log('Error: no port available');
                    }
					else
			  		{
		  				myConsole.log("It worked.");	
		  				bindPortEvent();
                        oui =1;
                        event.sender.send("connexion-finished", oui); 
			  		}
        }*/);
        
     

        port.open(function (err) {
            if (err){
                        event.sender.send("connexion-finished", err); 
                        event.sender.send("carteDeconnectee");
                        return myConsole.log('Error: no port available');
                    }
                    else
                    {
                        myConsole.log("It worked.");
                        //je ne sais pas ourquoi, mais il faut enlever ça, qui n'existait pas ailleurs anyway...???
                        //bindPortEvent();
                        oui =1;
                        event.sender.send("connexion-finished", oui); 
                    }
        });
        
  

});


//quand on appuie sur le bouton de déconnexion
ipc.on("deconnexion", function(event, arg){

        myConsole.log("déconnexion effectuée");
       
        if(port.isOpen){ 
            port.close();
            event.sender.send("deconnexion-finished", 1);        
        }
        else event.sender.send("carteDeconnectee");
            
    
        
        premier =1;
        //else event.sender.send("carteDeconnectee");
       
});


//port.on('error', showPortClose);

function showPortClose(){
    myConsole.log("carte déconnectée");
    
    
    
    
}
//jusqu'ici
/////////////////////////////////////////////////////////////////////////////////////////

ipc.on('demarrer',function(event, arg){
    myConsole.log("ici");
   
    if(port.isOpen){
       // port.flush();
       // port.resume();
    }
    else event.sender.send("carteDeconnectee");
    
    if(premier) {
        port.pipe(parser);
        if(connexion1) {
                    parser.on('data', function(data){
                    myConsole.log(data);
                    event.sender.send("donnees", data);
                
                });
            connexion1=0;
        };
        premier=0;
    }
    else  if(port.isOpen){
        //port.flush();
        //port.resume();
    }
    else event.sender.send("carteDeconnectee");
   
    
});


ipc.on('arreter', function(event, arg){
        if(port.isOpen){
           // port.pause();
            //port.flush();
       }  
        else event.sender.send("carteDeconnectee");
    
        
});

/*port.on('error', function(err) {
  myConsole.log('Error: ', err.message)
});
port.on('open', function() {
  myConsole.log("connecté");
})*/
//ne sert plus
/*function autoConnect(){
	serialPort.list().then( 
	function(ports)
	{
		ports.forEach( function(currentPort)
		{
			var manufact = currentPort.manufacturer;

			if( manufact.includes("arduino") )
			{
				port = new serialPort(currentPort.path,{baudRate:9600},function (err) 
				{
					if (err) 
			  			return myConsole.log('Error: no port available');
					else
			  		{
		  				myConsole.log("It worked.");	
		  				bindPortEvent();
			  		}
				});
			}
		});
	}).catch(function(e) {
  console.error(e.message); // "oh, no!"
});
}*/

/*port.on('close' ,(e)=>{
    
    if(!mainWindow.isClosing){
        e.preventDefault();
        mainWindow.webContents.send('carteDeconnectee');
        
    }
})*/

app.whenReady().then(createWindow);

function sendMessage(info){
  	port.write(info);
}


//#region MenuBuilding

//creation des menus
var mainMenuTemplate = [{
		label:'Application', 
		submenu:[ 
		{
			label: 'Quitter',
			accelerator: process.platform == 'darwin' ? 'Command+Q' : 'Ctrl+Q',
			click(){
			 app.quit();
			}	
		}]
}];


//rajoute un element vide sur Mac
if(process.platform == 'darwin'){
	
	mainMenuTemplate.unshift({label:''});
}

//aide pour le develeppoment
//aide pour le develeppoment
mainMenuTemplate.push(
    {
    label: "Édition",
    submenu: [
    { label: "Couper", accelerator: "CmdOrCtrl+X", selector: "cut:" },
    { label: "Copier", accelerator: "CmdOrCtrl+C", selector: "copy:" },
    { label: "Coller", accelerator: "CmdOrCtrl+V", selector: "paste:" },
    { label: "Tout sélectionner", accelerator: "CmdOrCtrl+A", selector: "selectAll:" }
    ]
    },
    {
        label:'Outils de développement',
        submenu:[
            {
                label:'Inspecter le code',
                accelerator: process.platform == 'darwin' ? 'Command+I':'Ctrl+I',
                click(item,focusedWindow){
                    focusedWindow.toggleDevTools();
                }
            },
            {
                 label: 'Recharger',  role: 'reload'
            }
        ],
    }
   
);
if (process.platform === 'darwin') {
  const name = app.getName();
  mainMenuTemplate.unshift({ label: name });
}

//#endregion